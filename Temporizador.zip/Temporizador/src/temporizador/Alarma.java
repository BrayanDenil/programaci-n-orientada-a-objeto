/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temporizador;

/**
 *
 * @author denil
 */
public class Alarma {
    private int tiempo;
    
    public Alarma(int tiempo){
    this.tiempo = tiempo;
    
    
    }
    public int getTiempo(){
    
    return tiempo;
    
    }
    
    public void activar(){
    System.out.println("¡Alarma activa! Tiempo alcanzado:" + tiempo+ "segundos");
    }
}
