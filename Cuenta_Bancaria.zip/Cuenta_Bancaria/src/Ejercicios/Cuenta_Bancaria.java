package Ejercicios;

/**
 *
 * @author denil
 */

//atributos privados
public class Cuenta_Bancaria {
 private String numeroCuenta;
 private int saldo;
 
 public  Cuenta_Bancaria(String numeroCuenta,int saldoInicial){
    this.numeroCuenta = numeroCuenta;
    this.saldo = saldoInicial;
    
    
}
 
 public void depositar(int cantidad){
     
     if(cantidad>0){
        saldo  += cantidad; 
        System.out.println("Deposito Con exito. Nuevo saldo:" + saldo);
         }
     else {
       System.out.println("Saldo Insuficiente para realizar el Retiro");
     }
     
 }
 
//constructor 
 public void retirar(int cantidad){
     if(cantidad>0 && saldo >=cantidad){
         
         saldo-= cantidad;
         System.out.println("Retiro Exitoso. Nuevo saldo:" + saldo);
         
     } else{ 
         System.out.println("Fondos insuficientes o cantidad invalida");
         
     }
     
     
     
 }
 
 
 public int consultarSaldo() {
 return saldo;
 
 }
  public String geNumeroCuenta() {
  return numeroCuenta;
  
  } 

    public static void main(String[] args) {
        Cuenta_Bancaria cuenta = new Cuenta_Bancaria("12345", (int) 2000.0);
        
         System.out.println("Saldo inicial: " + cuenta.consultarSaldo());
        
        // Depositar dinero
        cuenta.depositar((int) 800.0);
        
        // Intentar retirar dinero
        cuenta.retirar((int) 1200.0);
        
        // Consultar saldo después de las transacciones
        System.out.println("Saldo final: " + cuenta.consultarSaldo());
    }
    
}
