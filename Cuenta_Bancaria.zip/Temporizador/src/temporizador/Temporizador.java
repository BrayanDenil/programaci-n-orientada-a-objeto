package temporizador;

/**
 *
 * @author denil
 */
public class Temporizador {
    
 private int tiempoActual;
 private Alarma alarma;
 
 public Temporizador(){
 this.tiempoActual = 0;
 this.alarma = null;
 
 }
 
 public void iniciar(int segundos){
 for (int i = 1; i <= segundos; i++){ 
     this.tiempoActual = i;
     System.out.println("Tiempo Actual:"+this.tiempoActual+ "segundos");  
     
     if (alarma !=null && this.tiempoActual== alarma.getTiempo()){
     alarma.activar();
     }
     
     try {
         Thread.sleep(1000);
     }
     catch (InterruptedException e){
     e.printStackTrace();
             }
    }
  }
 
 public void asociarAlarma(Alarma alarma) {
        this.alarma = alarma;

 }
 public int getTiempoActual() {
        return this.tiempoActual;
    }
 
 
    public static void main(String[] args) {

Alarma alarma = new Alarma(6);

        
        Temporizador temporizador = new Temporizador();
        temporizador.asociarAlarma(alarma);

       
        System.out.println("Iniciando temporizador...");
        temporizador.iniciar(15); 
    }

}
