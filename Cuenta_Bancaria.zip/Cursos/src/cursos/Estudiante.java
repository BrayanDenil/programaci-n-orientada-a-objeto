/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cursos;

/**
 *
 * @author denil
 */
//atributos
public class Estudiante {
    private String nombre;
    private int carnet;
    private int notaFinal;
    
    public Estudiante(String nombre,int carnet, int notaFinal){
    this.carnet = carnet;
    this.nombre = nombre;
    this.notaFinal = notaFinal;
    

    
    
    
    
    }
    
    public String getNombre(){
    return this.nombre;
    
    }
    
    
    public void setNombre(String nombre){
    this.nombre= nombre;
    
    
    }

    public int getCarnet() {
        return carnet;
    }

    public void setCarnet(int carnet) {
        this.carnet = carnet;
    }

    public int getNotaFinal() {
        return notaFinal;
    }

    public void setNotaFinal(int notaFinal) {
        this.notaFinal = notaFinal;
    }

 
            
    //metodo
public void calcularPromedio(){

if(notaFinal >= 0 && notaFinal <=100){
    
    this.notaFinal = notaFinal;
}

else{
System.out.println("La noto debe estar entre 1 y 100.");

}
}

}    
    
    

