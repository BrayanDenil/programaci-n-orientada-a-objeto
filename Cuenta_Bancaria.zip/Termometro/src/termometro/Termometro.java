package termometro;

/**
 *
 * @author denil
 */
public class Termometro {
  private double celsius;
  
  public Termometro(double celsius){
  this.celsius= celsius;
  
  
  }

    public double getCelsius() {
        return celsius;
    }

    public void setCelsius(double celsius) {
        this.celsius = celsius;
    }
  
  
  public void setTemperatura(double celsius){
  this.celsius =celsius;
  
  
  }
  
  
  public double convertirAFahrenheit(){
  return (celsius *9/5)+32;
  }
   public double convertirAKelvin() {
        return celsius + 273.15;
   }
    public static void main(String[] args) {
     Termometro termometro1 = new Termometro(30.0);  // 25 grados Celsius

        // Obtener la temperatura en Celsius
        System.out.println("Temperatura en Celsius: " + termometro1.getCelsius() + " °C");

        // Convertir la temperatura a Fahrenheit
        double temperaturaFahrenheit = termometro1.convertirAFahrenheit();
        System.out.println("Temperatura en Fahrenheit: " + temperaturaFahrenheit + " °F");

        // Convertir la temperatura a Kelvin
        double temperaturaKelvin = termometro1.convertirAKelvin();
        System.out.println("Temperatura en Kelvin: " + temperaturaKelvin + " K");

        
        termometro1.setCelsius(90.0); 
        System.out.println("\nNueva temperatura en Celsius: " + termometro1.getCelsius() + " °C");
        System.out.println("Nueva temperatura en Fahrenheit: " + termometro1.convertirAFahrenheit() + " °F");
        System.out.println("Nueva temperatura en Kelvin: " + termometro1.convertirAKelvin() + " K");
    }
        
        
    }
    

