/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package productos_de_inventario;

/**
 *
 * @author denil
 */
public class Producto {
    private double codigo;
    private String nombre;
    private double precio;
    
    public Producto(double codigo,String nombre, double precio){
        this.codigo = codigo;
        this.nombre = nombre;
        
        
        setPrecio(precio);
        

}

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    
    
    public double getCodigo() {
        return codigo;
    }

    public void setCodigo(double codigo) {
        this.codigo = codigo;
    }

    

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        if ( precio < 0){
        this.precio = precio;
        }
             else { 
            this.precio = precio;
            System.out.println("el producto"+",Codigo: " +codigo + ", nombre:"+nombre + ",tiene un nuevo precio de :"+precio );
            
        }
        
    }

    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

       Producto Producto1 = new Producto( 1020 ,"Colgate",50);
             
               
    }}

    
       
    
    

